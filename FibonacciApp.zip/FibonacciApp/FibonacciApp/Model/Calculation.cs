﻿using FibonacciApp.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace FibonacciApp.Model
{
    class Calculation : ICalculation //Extends the interface and implements the methods defined. 
    {


        //0,1,1,2,3,5,8,13,21,34 - Standard Fib series
        //F(n)=F(n-1)+F(n-2) - Equation.
        //F(4)=2+1=3
        //F(8)=13+8=21

        public int GetNthNumber(int number)
        {
            //iterative method to get the Nth Number.
            int firstNumber = 0, secondNumber = 1;
            try
            {
                if (number <= 1)
                    return number;

                for (int i = 0; i < number - 1; i++)
                {
                    int nextNumber = firstNumber + secondNumber;
                    firstNumber = secondNumber;
                    secondNumber = nextNumber;
                }

            }
            catch (Exception)
            {

                throw;
            }
            
            return secondNumber;

        }

        public int GetNthNumberRecursive(int number)
        {
            //Recursive method to get the Nth Number.
            try
            {
                if (number <= 1)
                    return number;

                return (GetNthNumberRecursive(number - 1) + GetNthNumberRecursive(number - 2));
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
