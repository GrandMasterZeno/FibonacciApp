﻿using FibonacciApp.Model;
using System;

namespace FibonacciApp
{
    class Program
    {
        static void Main(string[] args)
        {

            ConsoleKeyInfo cki;
            Console.WriteLine("Press the Escape (Esc) key to quit.");

            do
            {

                Console.Write("Please enter a number(n) : ");

                Calculation calculation = new Calculation();

                try
                {
                    int NthNumber = int.Parse(Console.ReadLine());

                    if (NthNumber < 0)
                    {
                        Console.WriteLine("You must enter a positive number.");
                        break;
                    }

                    Console.WriteLine("The n-th number in the Fibonacci Series is : " + calculation.GetNthNumber(NthNumber));
                    //GetNthNumberRecursive - Recursive method can also  be used. 
                }
                catch (Exception)
                {
                    throw;
                }

                //Console.ReadKey();
                cki = Console.ReadKey();
            } while (cki.Key != ConsoleKey.Escape); //exit program when escape pressed. 
        }
    }
}
