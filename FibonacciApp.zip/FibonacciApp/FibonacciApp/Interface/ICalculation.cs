﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FibonacciApp.Interface
{
    interface ICalculation
    {
        int GetNthNumber(int number);

        int GetNthNumberRecursive(int number);
    }
}
